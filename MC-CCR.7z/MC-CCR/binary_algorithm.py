import numpy as np

from sklearn.model_selection import StratifiedKFold


def distance(x, y):
    return np.sum(np.abs(x - y))


def taxicab_sample(n, r):
    sample = []

    for _ in range(n):
        spread = r - np.sum([np.abs(x) for x in sample])
        sample.append(spread * (2 * np.random.rand() - 1))

    return np.random.permutation(sample)


class CCR:
    def __init__(self, classes_and_sizes,energy=0.25, scaling=0.0, n=None):
        self.classes_and_sizes = classes_and_sizes #排序后的类列表和数量列表
        self.energy = energy
        self.scaling = scaling
        self.n = n

    def compute_energy(self, idx, max_idx, middle_idx):
        if max_idx == middle_idx:
            return 1
        # 计算能量梯度
        energy_gradient = (0.5 - 1) / (max_idx-middle_idx )

        # 计算能量值
        energy = 0.5 + (idx - max_idx) * energy_gradient

        return energy
    '''
    x 实例
    y 标签
    return 重采样后的实例、标签和受影响的class_energies
    '''
    def fit_resample(self, X, y, class_idx): #X samples, Y labels
        classes, sizes = zip(*self.classes_and_sizes)
        classes = list(classes)
        print("class: ", classes)
        sizes = list(sizes)
        print("sizes: ", sizes)

        #print(type(X))
        #print(X)
        #print(type(y))
        #print(y)

        choosed_class = classes[class_idx]
        choosed = X[y==choosed_class] #当前扫描类
        #print(type(choosed), choosed)
        others = np.array([X[i] for i in range(len(X)) if y[i] != choosed_class]) #其余的类
        #print(type(others), others)
        others_labels = [y[i] for i in range(len(y)) if y[i] != choosed_class] #其余的类对应的label，现在others 和others label对应
        print("other labels: ", others_labels)
        #能够清理的类在class_idx左边，不能够清理的类在右边
        forbidden_classes = [classes[i] for i in range(len(classes)) if i > class_idx]
        allowed_classes = [classes[i] for i in range(len(classes)) if i < class_idx]
        print("fobidden classes: ", forbidden_classes)
        if self.n is None:
            n = sum(sizes[i]-sizes[class_idx] for i in range(len(sizes)) if i < class_idx) #能清理类的数量差
        else:
            n = self.n
        print("数量差： ", n)
        if n == 0:
            return X, y
        #energy = self.energy * (X.shape[1] ** self.scaling) #初始能量值 ： 现在没有考虑特征数
        #设定能量
        mid_idx = class_idx // 2
        #print(mid_idx)
        max_idx = 0
        energies = [self.compute_energy(idx, max_idx, mid_idx) for idx in range(class_idx)] #能量坐标与左边的类对应
        
        energies[-1] = self.energy
        print("energy : ", self.energy)
        #class_energies = zip(sorted_classes, sorted_sizes,energies)
        
        distances = np.zeros((len(choosed), len(others))) #初始化矩阵为0, 怎么确定distance和label的对应情况

        for i in range(len(choosed)):
            for j in range(len(others)):
                distances[i][j] = distance(choosed[i], others[j]) # 距离矩阵，每个实例的距离；行序号是choosed的
                #坐标，列序号是others的坐标
        radii = np.zeros(len(choosed)) # 少数类扩张的半径
        radii_first = np.zeros(len(choosed)) # 首次少数类扩张的半径

        translations = np.zeros(others.shape) # 多数类移动的记录矩阵

        for i in range(len(choosed)):
            first_flag = True#用于记录首次距离
            minority_point = choosed[i]
            remaining_energy = energies[-1]
            print("remaining energy: ", remaining_energy)
            r = 0.0
            sorted_distances = np.argsort(distances[i]) #sorted_distance 是排序后的索引数组
            sorted_distances_labels = [others_labels[idx] for idx in sorted_distances]
            distances_from_i = [distances[i][n] for n in sorted_distances]
            print("sorted distance index: ", sorted_distances)
            print("sorted distance label : ", sorted_distances_labels)
            print("sorted distance: ", distances_from_i)
            current_majority = 0 #清楚的多数类，同时也是每一列往下探查的列序号
            current_majority_energies = []

            while True:
                #检测是否需要继续
                if sorted_distances_labels[current_majority] in forbidden_classes:#如果下一个重叠类是forbidden类，停止
                    print(sorted_distances_labels[current_majority])
                    print("停止")
                    if first_flag:
                        radii_first[i] = 0
                        first_flag = False
                    break
                print("开始扫描")
                #找现在的多数类的能量
                current_majority_energy = [energies[n] for n in range(len(classes)) if classes[n] == sorted_distances_labels[current_majority]]
                
                if current_majority == n: #如果清楚掉了所有多数类，结束--可能性不大
                    print("数量为0")
                    if current_majority == 0:
                        radius_change = remaining_energy 
                    else:
                        radius_change = remaining_energy / sum(current_majority_energies) # 此时current_majority_energies应该不为空

                    r += radius_change
                    print(r)
                    if first_flag:
                        radii_first[i] = radius_change
                        first_flag = False
                    break

                radius_change = remaining_energy / (sum(current_majority_energies) + 1.0) #修改的半径是剩余能量/总清除能量之和

                if distances[i, sorted_distances[current_majority]] >= r + radius_change:#如果下一个多数类点的距离大于能够达到的距离
                    r += radius_change
                    if first_flag:
                        radii_first[i] = radius_change
                        first_flag = False
                    break
                else:
                    if current_majority == 0:
                        last_distance = 0.0
                    else:
                        last_distance = distances[i, sorted_distances[current_majority - 1]]

                    radius_change = distances[i, sorted_distances[current_majority]] - last_distance
                    if first_flag:
                        radii_first[i] = radius_change
                        first_flag = False
                    r += radius_change
                    current_majority_energies.append(current_majority_energy[0]) # current_majority_energy 应该只有一个能量值
                    print(current_majority_energies)
                    print(type(sum(current_majority_energies)), sum(current_majority_energies))
                    remaining_energy -= radius_change * (sum(current_majority_energies) + 1.0) # 能量损失公式：增长的半径*包含的所有多类实例数-->限制了扩张
                    current_majority += 1
            print("清楚的多数类数： ", current_majority)
            print("扩张的半径： ", r)
            print("首次扩张半径：", radii_first[i])
            radii[i] = r # 记录增长后的半径

            for j in range(current_majority): # 记录多数类实例的转变
                majority_point = others[sorted_distances[j]]
                d = distances[i, sorted_distances[j]] # 取得原本的距离

                if d < 1e-20: # 防止距离过小导致的计算误差
                    majority_point += (1e-6 * np.random.rand(len(majority_point)) + 1e-6) * \
                                      np.random.choice([-1.0, 1.0], len(majority_point))
                    d = distance(minority_point, majority_point)

                translation = (r - d) / d * (majority_point - minority_point) #修改量
                translations[sorted_distances[j]] += translation
        print("end")
        others += translations

        appended = [] # 人工合成的choosed 类实例
        print(type(radii), radii)

        no_null_radii = np.array([rad for rad in radii if rad != 0 ])
        print(type(radii), radii)
        # 这里基于的假设是在二分类中每个少数类一定能够扩张它的半径，但是这个在多数类中是不成立的。需要只对扩张了半径的当前类生成合成样本
        for i in range(len(choosed)): # 生成少数类
            minority_point = choosed[i]
            print(i, radii[i])
            if radii[i] == 0:
                continue
            synthetic_samples = int(np.round(1.0 / (radii[i] * np.sum(1.0 / no_null_radii)) * n)) #生成的样本数量
            r = radii[i]
            print('here', synthetic_samples)
            for _ in range(synthetic_samples):
                print('here1')
                appended.append(minority_point + taxicab_sample(len(minority_point), r))

        print(type(appended), appended)
        if len(appended) == 0:
            return np.concatenate([others, choosed]), \
                    np.concatenate([others_labels,
                               np.tile([choosed_class], len(choosed))])
        #这个标签库的建立建立在二分类只有多、少两种类型的情况下，在多数类中仍然不成立
        return np.concatenate([others, choosed, appended]), \
               np.concatenate([others_labels,
                               np.tile([choosed_class], len(choosed) + len(appended))])
        

class MCCR:
    def _init_(self, energy=0.25, scaling=0.0, n_list=None):
        self.energy=energy
        self.scaling=scaling
        self.n_list=n_list


    def fit_resample(self, x, y):#x instances;y labels
        classes = np.unique(y) #类别list，大小类
        sizes = [sum(y == c) for c in classes] #各类数量，现在就是大小类的数量

        

        zipped_lists = zip(classes, sizes)
        classes_and_sizes = sorted(zipped_lists, key=lambda i: i[1], reverse=True) #得到排序后的新class序列
        #sorted_classes, sorted_sizes = zip(*zipped_lists) 

        

        idx = 1 # 跳过最大多数类
        ccr = CCR(classes_and_sizes, 1.5)
        while idx < len(classes):
            print("第", idx, "次啊")
            x, y = ccr.fit_resample(x, y, idx)
            idx += 1

        return x, y


class CCRSelection:
    def __init__(self, classifier, measure, n_splits=5, energies=(0.25,), scaling_factors=(0.0,), n=None):
        self.classifier = classifier
        self.measure = measure
        self.n_splits = n_splits
        self.energies = energies
        self.scaling_factors = scaling_factors
        self.n = n
        self.selected_energy = None
        self.selected_scaling = None
        self.skf = StratifiedKFold(n_splits=n_splits)

    def fit_resample(self, X, y):
        self.skf.get_n_splits(X, y)

        best_score = -np.inf

        for energy in self.energies:
            for scaling in self.scaling_factors:
                scores = []

                for train_idx, test_idx in self.skf.split(X, y):
                    X_train, y_train = CCR(energy=energy, scaling=scaling, n=self.n).\
                        fit_resample(X[train_idx], y[train_idx])

                    classifier = self.classifier.fit(X_train, y_train)
                    predictions = classifier.predict(X[test_idx])
                    scores.append(self.measure(y[test_idx], predictions))

                score = np.mean(scores)

                if score > best_score:
                    self.selected_energy = energy
                    self.selected_scaling = scaling

                    best_score = score

        return CCR(energy=self.selected_energy, scaling=self.selected_scaling, n=self.n).fit_resample(X, y)
