from sklearn.metrics import confusion_matrix, accuracy_score, f1_score
from sklearn.utils.multiclass import unique_labels
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, recall_score, precision_score

def calculate_metrics(y_true, y_pred, classes):
    """
    计算给定类别的评估指标：AvAcc、CBA、mGM和CEN。

    参数:
    y_true -- 真实标签数组
    y_pred -- 预测标签数组
    classes -- 类别列表

    返回:
    dict -- 包含AvAcc、CBA、mGM和CEN的指标字典
    """
    # 计算混淆矩阵
    cm = confusion_matrix(y_true, y_pred, labels=classes).astype(np.float64)
    print(cm)
    
    # 计算AvAcc
    print("计算AvAcc：")
    Acces = []
    all_sum = np.sum(cm)
    print(all_sum)
    TPs = np.diag(cm) 
    for i in range(len(classes)):
        TN = all_sum - np.sum(cm[i, :]) - np.sum(cm[:, i]) + TPs[i]
        print(TN)
        Acc = (TPs[i] + TN) / all_sum
        Acces.append(Acc)
    AvAcc = np.mean(Acces)
    
    # 计算CBA
    CBA_scores = [] 
    mati_i = np.diag(cm)
    print(mati_i)
    
    for i in range(len(classes)):        
        CBA_scores.append(mati_i[i] / max(np.sum(cm[i, :]), np.sum(cm[:, i])))
    #CBA_scores = [mati_i / max(mati_o[i], mato_i) for i in range(len(classes))]
    CBA = np.mean(CBA_scores)
    
    # 计算mGM
    #mGM = np.sqrt(np.multiply(np.diag(cm), np.outer(np.diag(cm), np.sum(cm, axis=1)[:, None])).mean())
    recall = recall_score(y_true, y_pred, average='macro')
    precision = precision_score(y_true, y_pred, average='macro')
    beti = 1
    mGM = ((1+ beti*beti) * recall * precision) / ((beti*beti) * precision + recall)

    # 计算CEN
    confusion = cm[:-1, :-1]  # 移除对角线元素
    confusion[confusion == 0] = np.nan  # 防止0的log
    confusion = confusion / np.sum(confusion)  # 归一化混淆矩阵
    CEN = -np.nansum(confusion * np.log(confusion + 1e-10))
    
    return {'AvAcc': AvAcc, 'CBA': CBA, 'mGM': mGM, 'CEN': CEN}

def multiclass_evaluation(x_train, y_train, x_test, y_test):
    """
    评估多类别分类器的性能，并计算每个类别的AvAcc、CBA、mGM和CEN。

    参数:
    x_train -- 训练集特征
    y_train -- 训练集标签
    x_test -- 测试集特征
    y_test -- 测试集标签
    classes -- 类别列表

    返回:
    dict -- 包含每个类别评估指标的字典
    """
    # 训练分类器
    clf = RandomForestClassifier(n_estimators=10, criterion='gini')
    clf.fit(x_train, y_train)

    # 预测测试集的标签
    y_pred = clf.predict(x_test)

    classes = np.unique(y_test)
    print(classes)

    # 计算评估指标
    metrics = calculate_metrics(y_test, y_pred, classes=classes)

    return metrics
