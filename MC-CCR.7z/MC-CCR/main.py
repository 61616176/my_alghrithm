import prepare_resampled_data
import numpy as np

if __name__ == '__main__' :
    reses_1 = []
    reses_2 = []
    dataset = 'automobile'
    for a in 1,2,3,4,5:
        for b in 1,2:
            res_1, res_2 = prepare_resampled_data.prepare(dataset=dataset, partition=a, fold=b, cleaning_strategy='translate', method='sampling')
            reses_1.append(res_1)
            reses_2.append(res_2)
    
    AvAcces_1=[]
    F1s_1 = []
    CBAs_1 = []
    AvAcces_2=[]
    F1s_2 = []
    CBAs_2 = []
    for res in reses_1:
        for i in res:
            AvAcces_1.append(res['AvAcc'])
            F1s_1.append(res['mGM'])
            CBAs_1.append(res['CBA'])
    for res in reses_2:
        for i in res:
            AvAcces_2.append(res['AvAcc'])
            F1s_2.append(res['mGM'])
            CBAs_2.append(res['CBA'])

    AvAcc_1 = np.mean(AvAcces_1)
    F1_1 = np.mean(F1s_1)
    CBA_1 = np.mean(CBAs_1)

    AvAcc_2 = np.mean(AvAcces_2)
    F1_2 = np.mean(F1s_2)
    CBA_2 = np.mean(CBAs_2)

    print('AvAcc: ', AvAcc_1, 'F1: ', F1_1, 'CBA: ', CBA_1)
    print("********************")
    print('AvAcc: ', AvAcc_2, 'F1: ', F1_2, 'CBA: ', CBA_2)

